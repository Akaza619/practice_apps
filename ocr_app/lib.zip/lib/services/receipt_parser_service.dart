import '../models/receipt.dart';

class ParsedReceiptData {
  final String storeName;
  final DateTime? date;
  final double? total;
  final double? subtotal;
  final double? tax;
  final List<LineItem> items;

  ParsedReceiptData({
    required this.storeName,
    this.date,
    this.total,
    this.subtotal,
    this.tax,
    required this.items,
  });
}

class ReceiptParserService {
  ParsedReceiptData parse(String rawText) {
    final lines = rawText
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    return ParsedReceiptData(
      storeName: _extractStoreName(lines),
      date: _extractDate(rawText),
      total: _extractTotal(rawText),
      subtotal: _extractSubtotal(rawText),
      tax: _extractTax(rawText),
      items: _extractLineItems(lines),
    );
  }

  String _extractStoreName(List<String> lines) {
    // The store name is typically in the first 1–3 non-empty lines.
    // Filter out lines that look like addresses or phone numbers.
    final skipPatterns = RegExp(
      r'(\d{10}|\+91|ph:|tel:|gst|gstin|invoice|receipt|bill|tax)',
      caseSensitive: false,
    );
    for (final line in lines.take(5)) {
      if (line.length > 3 && !skipPatterns.hasMatch(line)) {
        return line;
      }
    }
    return 'Unknown store';
  }

  DateTime? _extractDate(String text) {
    // Matches: 19/04/2026, 19-04-2026, 19.04.2026, Apr 19 2026, 2026-04-19
    final patterns = [
      RegExp(r'\b(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{4})\b'),
      RegExp(r'\b(\d{4})[/\-\.](\d{1,2})[/\-\.](\d{1,2})\b'),
      RegExp(
        r'\b(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{4})\b',
        caseSensitive: false,
      ),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(text);
      if (match != null) {
        try {
          if (pattern.pattern.startsWith(r'\b(\d{4})')) {
            return DateTime(
              int.parse(match.group(1)!),
              int.parse(match.group(2)!),
              int.parse(match.group(3)!),
            );
          } else {
            return DateTime(
              int.parse(match.group(3)!),
              int.parse(match.group(2)!),
              int.parse(match.group(1)!),
            );
          }
        } catch (_) {
          continue;
        }
      }
    }
    return null;
  }

  double? _extractTotal(String text) {
    final patterns = [
      RegExp(
        r'(?:grand\s*total|total\s*amount|net\s*total|amount\s*due|total)[^\d]*?(\d[\d,]*\.?\d{0,2})',
        caseSensitive: false,
      ),
      RegExp(
        r'(?:rs\.?|inr|₹)\s*(\d[\d,]*\.?\d{0,2})\s*$',
        caseSensitive: false,
        multiLine: true,
      ),
    ];

    double? best;
    for (final pattern in patterns) {
      final matches = pattern.allMatches(text);
      for (final match in matches) {
        final val = _parseAmount(match.group(1)!);
        if (val != null && (best == null || val > best)) {
          best = val;
        }
      }
      if (best != null) break;
    }
    return best;
  }

  double? _extractSubtotal(String text) {
    final regex = RegExp(
      r'(?:subtotal|sub-total|sub total)[^\d]*(\d[\d,]*\.?\d{0,2})',
      caseSensitive: false,
    );
    return _parseAmount(regex.firstMatch(text)?.group(1) ?? '');
  }

  double? _extractTax(String text) {
    final regex = RegExp(
      r'(?:gst|tax|vat|cgst|sgst|igst)[^\d]*(\d[\d,]*\.?\d{0,2})',
      caseSensitive: false,
    );
    double? total;
    for (final match in regex.allMatches(text)) {
      final val = _parseAmount(match.group(1)!);
      if (val != null) total = (total ?? 0) + val;
    }
    return total;
  }

  List<LineItem> _extractLineItems(List<String> lines) {
    final items = <LineItem>[];

    // Pattern: "Item name    12.99" or "Item name    2    12.99"
    final withQty = RegExp(
      r'^(.+?)\s{2,}(\d+(?:\.\d+)?)\s{2,}(\d[\d,]*\.\d{2})\s*$',
    );
    final withPrice = RegExp(
      r'^(.+?)\s{2,}(\d[\d,]*\.\d{2})\s*$',
    );

    // Lines that are obviously headers or totals — skip them
    final skipWords = RegExp(
      r'^(item|description|qty|price|amount|subtotal|total|tax|gst|cgst|sgst|discount|date|invoice|receipt|bill|store|address|phone|gstin)',
      caseSensitive: false,
    );

    for (final line in lines) {
      if (skipWords.hasMatch(line)) continue;

      var m = withQty.firstMatch(line);
      if (m != null) {
        final price = _parseAmount(m.group(3)!);
        final qty = double.tryParse(m.group(2)!) ?? 1.0;
        if (price != null && price > 0 && price < 1000000) {
          items.add(LineItem(name: m.group(1)!.trim(), price: price, quantity: qty));
          continue;
        }
      }

      m = withPrice.firstMatch(line);
      if (m != null) {
        final price = _parseAmount(m.group(2)!);
        if (price != null && price > 0 && price < 1000000) {
          items.add(LineItem(name: m.group(1)!.trim(), price: price));
        }
      }
    }

    return items;
  }

  double? _parseAmount(String raw) {
    if (raw.isEmpty) return null;
    final cleaned = raw.replaceAll(',', '').trim();
    return double.tryParse(cleaned);
  }

  /// Suggest a category based on store name keywords.
  String suggestCategory(String storeName) {
    final s = storeName.toLowerCase();
    if (RegExp(r'restaurant|cafe|food|pizza|burger|swiggy|zomato|kitchen').hasMatch(s)) {
      return 'Food & dining';
    }
    if (RegExp(r'pharmacy|medical|chemist|health|hospital|clinic').hasMatch(s)) {
      return 'Healthcare';
    }
    if (RegExp(r'supermart|grocery|fresh|bazaar|vegetables|fruits|kirana').hasMatch(s)) {
      return 'Groceries';
    }
    if (RegExp(r'petrol|fuel|gas|cng|hp|iocl|bpcl').hasMatch(s)) {
      return 'Fuel';
    }
    if (RegExp(r'fashion|clothing|wear|garment|apparel|lifestyle').hasMatch(s)) {
      return 'Fashion';
    }
    if (RegExp(r'digital|electronics|mobile|laptop|apple|samsung|computer').hasMatch(s)) {
      return 'Electronics';
    }
    return 'General';
  }
}
