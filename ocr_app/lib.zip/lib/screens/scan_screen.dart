import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:uuid/uuid.dart';
import '../models/receipt.dart';
import '../services/ocr_service.dart';
import '../services/receipt_parser_service.dart';
import '../services/storage_service.dart';
import 'receipt_detail_screen.dart';

enum ScanState { idle, processing, error }

class ScanScreen extends StatefulWidget {
  final StorageService storage;
  const ScanScreen({super.key, required this.storage});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final _picker = ImagePicker();
  final _ocr = OcrService();
  final _parser = ReceiptParserService();
  final _uuid = const Uuid();

  ScanState _state = ScanState.idle;
  String _statusMessage = '';
  String? _errorMessage;

  @override
  void dispose() {
    _ocr.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan receipt')),
      body: _state == ScanState.processing
          ? _ProcessingView(message: _statusMessage)
          : _state == ScanState.error
          ? _ErrorView(
              message: _errorMessage ?? 'Something went wrong',
              onRetry: _reset,
            )
          : _IdleView(
              onCamera: () => _capture(ImageSource.camera),
              onGallery: () => _capture(ImageSource.gallery),
            ),
    );
  }

  void _reset() {
    setState(() {
      _state = ScanState.idle;
      _errorMessage = null;
    });
  }

  Future<void> _capture(ImageSource source) async {
    try {
      final file = await _picker.pickImage(
        source: source,
        imageQuality: 90,
        preferredCameraDevice: CameraDevice.rear,
      );
      if (file == null) return;

      setState(() {
        _state = ScanState.processing;
        _statusMessage = 'Compressing image...';
      });

      // Compress for faster OCR
      final compressed = await FlutterImageCompress.compressAndGetFile(
        file.path,
        '${file.path}_compressed.jpg',
        quality: 85,
        minWidth: 1200,
        minHeight: 1600,
      );
      final imagePath = compressed?.path ?? file.path;

      setState(() => _statusMessage = 'Running OCR...');
      final rawText = await _ocr.extractText(imagePath);

      if (rawText.isEmpty) {
        setState(() {
          _state = ScanState.error;
          _errorMessage =
              'No text found in image. Try a clearer photo with good lighting.';
        });
        return;
      }

      setState(() => _statusMessage = 'Parsing receipt...');
      final parsed = _parser.parse(rawText);

      final receipt = Receipt(
        id: _uuid.v4(),
        storeName: parsed.storeName,
        date: parsed.date ?? DateTime.now(),
        total: parsed.total ?? _calculateTotal(parsed.items),
        items: parsed.items,
        category: _parser.suggestCategory(parsed.storeName),
        imagePath: imagePath,
        rawText: rawText,
        scannedAt: DateTime.now(),
      );

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ReceiptDetailScreen(
            receipt: receipt,
            storage: widget.storage,
            isNew: true,
          ),
        ),
      );
    } catch (e) {
      setState(() {
        _state = ScanState.error;
        _errorMessage = 'Error processing image: ${e.toString()}';
      });
    }
  }

  double _calculateTotal(List<LineItem> items) =>
      items.fold(0, (sum, item) => sum + item.total);
}

class _IdleView extends StatelessWidget {
  final VoidCallback onCamera;
  final VoidCallback onGallery;

  const _IdleView({required this.onCamera, required this.onGallery});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.document_scanner,
            size: 96,
            color: Theme.of(context).colorScheme.primary.withOpacity(.3),
          ),
          const SizedBox(height: 32),
          const Text(
            'How do you want to scan?',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          Text(
            'Take a photo of your receipt or pick one from your gallery.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(.6),
            ),
          ),
          const SizedBox(height: 40),
          Row(
            children: [
              Expanded(
                child: _OptionCard(
                  icon: Icons.camera_alt,
                  label: 'Camera',
                  subtitle: 'Take a new photo',
                  onTap: onCamera,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _OptionCard(
                  icon: Icons.photo_library,
                  label: 'Gallery',
                  subtitle: 'Choose existing',
                  onTap: onGallery,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Card(
            color: Theme.of(context).colorScheme.secondaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    Icons.tips_and_updates,
                    color: Theme.of(context).colorScheme.onSecondaryContainer,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'For best results, lay the receipt flat on a dark surface with good lighting.',
                      style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(
                          context,
                        ).colorScheme.onSecondaryContainer,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OptionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _OptionCard({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(
                icon,
                size: 36,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 10),
              Text(
                label,
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  color: Theme.of(
                    context,
                  ).colorScheme.onSurface.withOpacity(.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProcessingView extends StatelessWidget {
  final String message;
  const _ProcessingView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 24),
          Text(
            message,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          Text(
            'This may take a few seconds',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(.6),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            const Text(
              'Scan failed',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(.6),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Try again'),
            ),
          ],
        ),
      ),
    );
  }
}
